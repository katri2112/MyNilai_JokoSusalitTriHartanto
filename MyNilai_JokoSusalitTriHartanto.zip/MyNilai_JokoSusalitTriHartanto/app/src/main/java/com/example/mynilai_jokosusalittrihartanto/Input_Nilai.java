package com.example.mynilai_jokosusalittrihartanto;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Input_Nilai extends AppCompatActivity {

    EditText anim, anama, akehadiran, atugas, auts, auas;
    Button Vsubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input_nilai);

        String matkul = getIntent().getExtras().getString("matkul");
        anim = findViewById(R.id.nim);
        anama = findViewById(R.id.Nama);
        akehadiran = findViewById(R.id.Kehadiran);
        atugas = findViewById(R.id.Tugas);
        auts = findViewById(R.id.UTS);
        auas = findViewById(R.id.UAS);

        Vsubmit= findViewById(R.id.submit);
        Vsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Input_Nilai.this, Bobot_Penilaian.class);
                i.putExtra("kehadiran", akehadiran.getText().toString());
                i.putExtra("tugas", atugas.getText().toString());
                i.putExtra("uts", auts.getText().toString());
                i.putExtra("uas", auas.getText().toString());
                i.putExtra("nama", anama.getText().toString());
                i.putExtra("nim", anim.getText().toString());
                i.putExtra("matkul", matkul);
                startActivity(i);
            }
        });
    }
}