package com.example.mynilai_jokosusalittrihartanto;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;

public class Hasil_Akhir extends AppCompatActivity {

    EditText Nnim, nnama, Pakhir, Pnilai;
    TextView tvMatkul;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hasil_akhir);

        Nnim = findViewById(R.id.jnim);
        nnama = findViewById(R.id.jnama);
        Pakhir= findViewById(R.id.JAkhir);
        Pnilai = findViewById(R.id.Grade);

        String akhir = getIntent().getExtras().getString("akhir");
        String grade = getIntent().getExtras().getString("grade");
        String matkul = getIntent().getExtras().getString("matkul");

//        Log.d(akhir, "onCreate: ");
        tvMatkul = findViewById(R.id.tvMatkul);
        tvMatkul.setText(matkul);

        Pakhir.findViewById(R.id.JAkhir);
        Pakhir.setText(akhir);

        Pnilai.findViewById(R.id.Grade);
        Pnilai.setText(grade);

        String nim = getIntent().getExtras().getString("nim");
        String nama = getIntent().getExtras().getString("nama");

        Nnim.findViewById(R.id.jnim);
        Nnim.setText(nim);

        nnama.findViewById(R.id.jnama);
        nnama.setText(nama);
    }
}